using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemymovement : MonoBehaviour
{
    public GameObject [] wayPoint;
    public float speed = 5f;
    private int currentPoint= 0;
    private float wayPointRadius = 1;
    public bool enemyMovement = true;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
       
        if (Input.GetKeyDown("j")){
           enemyMovement = !enemyMovement;
        } 

        if(enemyMovement){
            sequentialMove();
            
        } else {
            randomMove();
            
        }
    
    }
    public void sequentialMove(){
        
        if (Vector3.Distance(wayPoint[currentPoint].transform.position, transform.position) < wayPointRadius){
            currentPoint++;
            if(currentPoint >= wayPoint.Length){
                currentPoint = 0;
            }
        }
        transform.position = Vector3.MoveTowards(transform.position, wayPoint[currentPoint].transform.position, speed * Time.smoothDeltaTime);
        
    }
    public void randomMove(){
        
        if (Vector3.Distance(wayPoint[currentPoint].transform.position, transform.position) < wayPointRadius){
            currentPoint = Random.Range(0,wayPoint.Length);
            if(currentPoint >= wayPoint.Length){
                currentPoint = 0;
            }
        }
        transform.position = Vector3.MoveTowards(transform.position, wayPoint[currentPoint].transform.position, speed * Time.smoothDeltaTime);
        
    }
}
